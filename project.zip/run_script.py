from keio2020adp_21845969_project.cellular_automaton import Cellular_Automaton
ca = Cellular_Automaton('ca_input.txt')
ca.processing('ca_output.txt', 100)